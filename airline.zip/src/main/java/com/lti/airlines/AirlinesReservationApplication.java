package com.lti.airlines;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlinesReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlinesReservationApplication.class, args);
	}

}

